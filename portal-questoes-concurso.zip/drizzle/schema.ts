import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  json,
  longtext,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Categories (subjects/disciplines)
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 7 }),
  order: int("order").default(0),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Banks (examining boards)
 */
export const banks = mysqlTable("banks", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  description: text("description"),
  logo: varchar("logo", { length: 255 }),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Bank = typeof banks.$inferSelect;
export type InsertBank = typeof banks.$inferInsert;

/**
 * Difficulty levels
 */
export const difficultyLevels = mysqlTable("difficulty_levels", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
  level: int("level").notNull(),
  color: varchar("color", { length: 7 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DifficultyLevel = typeof difficultyLevels.$inferSelect;
export type InsertDifficultyLevel = typeof difficultyLevels.$inferInsert;

/**
 * Questions
 */
export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull(),
  bankId: int("bankId").notNull(),
  difficultyId: int("difficultyId").notNull(),
  year: int("year"),
  questionText: longtext("questionText").notNull(),
  alternatives: json("alternatives").$type<{
    a: string;
    b: string;
    c: string;
    d: string;
    e?: string;
  }>().notNull(),
  correctAnswer: varchar("correctAnswer", { length: 1 }).notNull(),
  explanation: longtext("explanation"),
  source: varchar("source", { length: 255 }),
  isActive: boolean("isActive").default(true),
  generatedByLLM: boolean("generatedByLLM").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

/**
 * User answers and performance tracking
 */
export const userAnswers = mysqlTable("user_answers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  questionId: int("questionId").notNull(),
  selectedAnswer: varchar("selectedAnswer", { length: 1 }).notNull(),
  isCorrect: boolean("isCorrect").notNull(),
  timeSpent: int("timeSpent"), // in seconds
  attemptNumber: int("attemptNumber").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserAnswer = typeof userAnswers.$inferSelect;
export type InsertUserAnswer = typeof userAnswers.$inferInsert;

/**
 * User statistics and performance summary
 */
export const userStats = mysqlTable("user_stats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  totalAnswered: int("totalAnswered").default(0),
  totalCorrect: int("totalCorrect").default(0),
  totalIncorrect: int("totalIncorrect").default(0),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }).default("0.00"),
  currentStreak: int("currentStreak").default(0),
  bestStreak: int("bestStreak").default(0),
  totalTimeSpent: int("totalTimeSpent").default(0), // in seconds
  lastActivityAt: timestamp("lastActivityAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserStat = typeof userStats.$inferSelect;
export type InsertUserStat = typeof userStats.$inferInsert;

/**
 * Category-specific statistics for users
 */
export const userCategoryStats = mysqlTable("user_category_stats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categoryId: int("categoryId").notNull(),
  totalAnswered: int("totalAnswered").default(0),
  totalCorrect: int("totalCorrect").default(0),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }).default("0.00"),
  lastAnsweredAt: timestamp("lastAnsweredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserCategoryStat = typeof userCategoryStats.$inferSelect;
export type InsertUserCategoryStat = typeof userCategoryStats.$inferInsert;

/**
 * Simulated exams (timed tests)
 */
export const simulados = mysqlTable("simulados", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  categoryId: int("categoryId"),
  bankId: int("bankId"),
  totalQuestions: int("totalQuestions").notNull(),
  totalCorrect: int("totalCorrect").default(0),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }).default("0.00"),
  timeLimit: int("timeLimit"), // in seconds
  timeSpent: int("timeSpent"), // in seconds
  status: mysqlEnum("status", ["in_progress", "completed"]).default("in_progress"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Simulado = typeof simulados.$inferSelect;
export type InsertSimulado = typeof simulados.$inferInsert;

/**
 * Ads configuration for monetization
 */
export const ads = mysqlTable("ads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  placement: mysqlEnum("placement", [
    "header_banner",
    "sidebar_top",
    "sidebar_middle",
    "sidebar_bottom",
    "between_questions",
    "footer",
  ]).notNull(),
  adCode: longtext("adCode").notNull(),
  isActive: boolean("isActive").default(true),
  priority: int("priority").default(0),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ad = typeof ads.$inferSelect;
export type InsertAd = typeof ads.$inferInsert;

/**
 * SEO metadata for pages
 */
export const seoMetadata = mysqlTable("seo_metadata", {
  id: int("id").autoincrement().primaryKey(),
  path: varchar("path", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  keywords: text("keywords"),
  ogImage: varchar("ogImage", { length: 255 }),
  ogTitle: varchar("ogTitle", { length: 255 }),
  ogDescription: text("ogDescription"),
  canonicalUrl: varchar("canonicalUrl", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SeoMetadata = typeof seoMetadata.$inferSelect;
export type InsertSeoMetadata = typeof seoMetadata.$inferInsert;
