import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import SEO from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function Questions() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [result, setResult] = useState<{ isCorrect: boolean; correctAnswer: string; explanation?: string } | null>(null);

  const [filters, setFilters] = useState({
    categoryId: "",
    bankId: "",
    difficultyId: "",
  });

  const { data: categories } = trpc.categories.list.useQuery();
  const { data: banks } = trpc.banks.list.useQuery();
  const { data: difficultyLevels } = trpc.difficultyLevels.list.useQuery();
  const { data: questions, isLoading } = trpc.questions.list.useQuery({
    categoryId: filters.categoryId ? parseInt(filters.categoryId) : undefined,
    bankId: filters.bankId ? parseInt(filters.bankId) : undefined,
    difficultyId: filters.difficultyId ? parseInt(filters.difficultyId) : undefined,
    limit: 100,
  });

  const submitAnswerMutation = trpc.userAnswers.submit.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setShowResult(true);
    },
    onError: (error) => {
      toast.error(`Erro ao enviar resposta: ${error.message}`);
    },
  });

  useEffect(() => {
    if (!user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  if (!user) {
    return null;
  }

  const currentQuestion = questions?.[currentQuestionIndex];

  const handleSubmitAnswer = () => {
    if (!currentQuestion || !selectedAnswer) {
      toast.error("Selecione uma resposta");
      return;
    }

    submitAnswerMutation.mutate({
      questionId: currentQuestion.id,
      selectedAnswer: selectedAnswer as "a" | "b" | "c" | "d" | "e",
    });
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < (questions?.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setResult(null);
    } else {
      toast.success("Você respondeu todas as questões!");
      setLocation("/stats");
    }
  };

  return (
    <>
      <SEO
        title="Resolver Questões - Portal de Concursos"
        description="Resolva questões de concurso público em Português, Matemática e Informática. Pratique com filtros por categoria, banca e dificuldade."
        keywords="questões, concurso, português, matemática, informática"
        noindex={true}
      />
      <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              size="sm"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold gradient-text">Resolver Questões</h1>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="category">Categoria</Label>
                  <Select
                    value={filters.categoryId}
                    onValueChange={(value) =>
                      setFilters({ ...filters, categoryId: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todas as categorias" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas as categorias</SelectItem>
                      {categories?.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id.toString()}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="bank">Banca</Label>
                  <Select
                    value={filters.bankId}
                    onValueChange={(value) =>
                      setFilters({ ...filters, bankId: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todas as bancas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas as bancas</SelectItem>
                      {banks?.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id.toString()}>
                          {bank.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="difficulty">Dificuldade</Label>
                  <Select
                    value={filters.difficultyId}
                    onValueChange={(value) =>
                      setFilters({ ...filters, difficultyId: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todas as dificuldades" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas as dificuldades</SelectItem>
                      {difficultyLevels?.map((level) => (
                        <SelectItem key={level.id} value={level.id.toString()}>
                          {level.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Question Card */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : currentQuestion ? (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Questão {currentQuestionIndex + 1}</CardTitle>
                  <CardDescription>
                    {currentQuestionIndex + 1} de {questions?.length || 0}
                  </CardDescription>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Progresso</p>
                  <p className="text-lg font-semibold">
                    {Math.round(((currentQuestionIndex + 1) / (questions?.length || 1)) * 100)}%
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <p className="text-lg font-semibold mb-4">{currentQuestion.questionText}</p>
              </div>

              {!showResult ? (
                <>
                  <RadioGroup value={selectedAnswer || ""} onValueChange={setSelectedAnswer}>
                    <div className="space-y-3">
                      {["a", "b", "c", "d", "e"].map((letter) => {
                        const alternative =
                          currentQuestion.alternatives[letter as keyof typeof currentQuestion.alternatives];
                        if (!alternative) return null;

                        return (
                          <div key={letter} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer">
                            <RadioGroupItem value={letter} id={letter} />
                            <Label htmlFor={letter} className="flex-1 cursor-pointer">
                              <span className="font-semibold mr-2">{letter.toUpperCase()})</span>
                              {alternative}
                            </Label>
                          </div>
                        );
                      })}
                    </div>
                  </RadioGroup>

                  <Button
                    onClick={handleSubmitAnswer}
                    disabled={!selectedAnswer || submitAnswerMutation.isPending}
                    className="w-full"
                    size="lg"
                  >
                    {submitAnswerMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verificando...
                      </>
                    ) : (
                      "Verificar Resposta"
                    )}
                  </Button>
                </>
              ) : result ? (
                <>
                  <div className={`p-4 rounded-lg ${result.isCorrect ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {result.isCorrect ? (
                        <>
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                          <p className="font-semibold text-green-600">Resposta Correta!</p>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-5 w-5 text-red-600" />
                          <p className="font-semibold text-red-600">Resposta Incorreta</p>
                        </>
                      )}
                    </div>
                    <p className="text-sm">
                      Resposta correta: <span className="font-semibold">{result.correctAnswer.toUpperCase()}</span>
                    </p>
                  </div>

                  {result.explanation && (
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="font-semibold text-blue-900 mb-2">Explicação:</p>
                      <p className="text-sm text-blue-800">{result.explanation}</p>
                    </div>
                  )}

                  <Button
                    onClick={handleNextQuestion}
                    className="w-full"
                    size="lg"
                  >
                    {currentQuestionIndex < (questions?.length || 0) - 1
                      ? "Próxima Questão"
                      : "Finalizar"}
                  </Button>
                </>
              ) : null}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">Nenhuma questão encontrada com os filtros selecionados.</p>
            </CardContent>
          </Card>
        )}
      </div>
      </div>
    </>
  );
}