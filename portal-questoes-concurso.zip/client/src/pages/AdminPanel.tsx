import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import SEO from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, ArrowLeft } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import QuestionsManagerV2 from "@/components/admin/QuestionsManagerV2";
import CategoriesManager from "@/components/admin/CategoriesManager";
import BanksManager from "@/components/admin/BanksManager";
import AdsManager from "@/components/admin/AdsManager";
import AdminDashboard from "@/components/admin/AdminDashboard";

export default function AdminPanel() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user && user.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Você não tem permissão para acessar o painel administrativo.
              </AlertDescription>
            </Alert>
            <Button
              onClick={() => setLocation("/")}
              className="w-full mt-4"
              variant="outline"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <SEO
        title="Painel Administrativo - Portal de Concursos"
        description="Gerencie questões, categorias, bancas e anúncios do portal."
        keywords="admin, painel, gestão"
        noindex={true}
      />
      <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold gradient-text">Painel Administrativo</h1>
              <p className="text-muted-foreground mt-2">
                Gerencie questões, categorias, bancas e anúncios
              </p>
            </div>
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              size="sm"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="questions">Questões</TabsTrigger>
            <TabsTrigger value="categories">Categorias</TabsTrigger>
            <TabsTrigger value="banks">Bancas</TabsTrigger>
            <TabsTrigger value="ads">Anúncios</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <AdminDashboard />
          </TabsContent>

          <TabsContent value="questions" className="space-y-4">
            <QuestionsManagerV2 />
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <CategoriesManager />
          </TabsContent>

          <TabsContent value="banks" className="space-y-4">
            <BanksManager />
          </TabsContent>

          <TabsContent value="ads" className="space-y-4">
            <AdsManager />
          </TabsContent>
        </Tabs>
      </div>
      </div>
    </>
  );
}
